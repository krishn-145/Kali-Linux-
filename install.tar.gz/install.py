#!/usr/bin/env python3

# ============================================================
#                   </> : TOOL NAME OPN ||
#                       OWNER : Krishn 🔱 
# 		   </> :  FOLLW IN INSTAGRAM : ur_.krishn._02
# ============================================================

import base64
import gzip
import os
import subprocess
import sys


PAYLOAD = 'H4sIAAAAAAAC/6162bLsRnbds/kVx9SDSENNzFOHWhEoDIWxgAJQmOQOBqbCPM+w/Bd+9zf4z/wJxr2XTfKy2ZJtCXEiDk4id+ae1l474+Tf/WdwmUYwKlowbdeP/pjzrkW/+ebvPv7073gu8b9+/hH8p48/fti6rn48GI3/0I3Hx7/8y+9O/fTo7oM3LwFlLKa8/fjf//N//K+Pa/J/+k8/L/Uh6KrqfkiP68eymbvJaNfoMv74Q/VZ5ocfIeTfa8g3RdN34/wRhVNKYH/5KzuL/i/v3fSXt2mJ+rGL0+mXkWP65ptvDMZXdYb7+NPH34vYJDFfHhYkYMJN1OqQxZSinz3YVICtvhl12aLIzhv39pAkRqiYrnl0vZPfdpVcmxxiSXTk1CEoC45yYnQZF6xR/IbvnaqQ6K18G2tsWOeRgJRyLhqTVy9OntADXmAbLaMu3wAwBdfSANmYVGkAzFGqJGNwFRpiHPH+5GEM2tCZtEGQOhMZ3cEE8m3xCBltDzI0AkHyDRIGCDoIv4LqCh4YLC/dQIyn3KztTlr+gel4GxonpdclELQtdsQS8IodwOFenj1rEcJvcmYjNQwGL88EUxcUV/J4xHT2iAJLMzB0wrDYELfz/kLd+/vSFyFpGWGz09sxXb4zMZt43rt3B1bKE0fjOle1cWUiA6esJwPQl/C1JwA9LjyrN/irCBkXZO+bvXHidqhzv08HwHtJAFQ8um2ifJcfesS8Mi87DWkJBX65NXg97jvPSHZNmxOr4jeOPOQ6t7VD8SFCqtiN3QTGHVLYDPyakZRbraR4x3DPZGiewp218baDQe6F3KMpfklV9tT44unz1vu8MTuk8F2AOORMOxNHIw2F6bw4yGvw1JeM4x5dl/KgpajVmhpKVlhxMFG+XsZAOQjVNr6UDWFd7ibwyg02rhQ6CIEgS/183TCBf5d428bnI807g+XLuVaJmUuV2744a6AOz8N/ZeNG42PhEz0oYw2eZCcUOXaI8WpwP+6HVYwDM70JF7UwBhRM26O8lh0INTxZ3aNG2TYNiaTqJWOpcMwA6nCsUsuKQq4FylsH/dbY7eYDLEFWarL4BELP6ErYy1ts5BuvTTgDPc88lJ8QMms+0oUkQd7vRMvpZ3qk9pXB8NQnoloXKiGVWzZAdtmdjzcqvAUFxVqhGs3cbe5lEvv3Hn/i3VHcnvZruFvROyOfD9oQyDs9KiWvn+FCaKYoYHYdBRK0w9Jsu3eMQmOV8zG/gRPzZkp0XOsIhp45iaNd5qAIK6FVaTHA0jsc/DaV1uPWdeF8sgkeoFsUAgijFTIg5MPy7gp+wcVuojoQkFoK8e48lPx+k9AwT+GMXZa7yhaT2m9P70wU6NHzZTzICxcqZAU0nOSvbpQtp6wja+Aw8Imp5fEUxIzWBisTNYFzI+KA7SCC0FVC18iEpzXOrUQ42q5tnymG743xqi3a8dRJ7Aezemyb/5a8l5QHQJiE3H6MZ/72IhbQY5FV5Sgaa0hboWzP7Bk6H4OwW5ruMh6QV0KjxCw5+rmxw8lqxch9Z4QDx3M9P67Qx1Hq734QaWGcExicnDsSsSPWd+Iu61uhWudepMv5sNSd6y0BSlMxxBEFvd+pvJaU+SG06T29QQFqzIRLrJ2EechB6YjavpP9Vhj8ISbr/LpHWRHAi4+Djy6XEldVHjErz+TKe4+VisRTquF0Fewh2t8yF6C01MfHcDDBFqz27DuHabWUBRnLCXXY7apF0V2eWqCeXwGDEHxlzXrNYZWIwEReK3rkSPxhsLuAQhCy7+lw6xDXHoYFWpIXTJG29mpX4nyyD0RUOhpZfY9vVRvuz12KIzl07VNcm7GVEA33NL2ItfyeJnl/Ivi4dcWwAbf4wJ2+780zKJ60kOlnxEXIPBCyi7DhotsUlI+hTb0WHBUiqje8/UReBcDzVO1zmn62MpItEVPUbewutBE+TlMhh4lNfU4QX49NwiNfezKEW7et1AzLEUIk1A9x5wpcTInT5ulEO1tAVS6uPxnjvgAnsBQOqN4CRRRvAhrO/FnJ7cY/QTE0pjYYbbvQWzvipCfvlY60Uv5Q37Iw54NWWJ9pcytHze0Jm72vuY9z0cuEHnTDKwWeCQQOcGUz2nm/LQ6xVpHV2pCHZJa/AMfmZLWi0JikUX5C4JtebSbay0mi4yfcBPxOGkAc+f4joOkDsIn0gSLezYCKpjhHZu/Wo3k6gsEqAuyFJotgi3ESznhBl4D38jl7qVcnYUJIC2/ht4Z9dvMjYLQgAQax4Rrc8UBNSKXMfxPNxDipcDdlueC2vE9PAWlStYdDvNzB521Uroryfi8JOmyUk1n31p8f9011hrGkj+wmgLZ2ZT2AMxEzd5ntUFxdx3SQEJqfXPmBH02RMGK5uwN5RtAG1/MxUm9aS2sGbEZxLp2N90jo0YjpiVoGsD+13m7BVz0LSv8siKOEbq/whfJh4SWY//IU1TkGHjPg4xQkh7+ppHcjuKq5m9zxMLMZSgVovvlyRsmalLxGg/csBjqlIa7gfk0qHW5c9HWHHkR1j2dDYVW1IFy4M57HXOoVel5UhoR4IJBxvmsm6SWl6ZtyQa0I0T5Fughq8Uzzy1gmR1clubyKCTsOyoUK7YD6FjRxn1LL3buJeY0XT2HqaY9pR8kAmSvAbD14thh8M1VoHQK8jr+2n3Sh9UY4tFFbuFEVXi4JHehVYAsvQ9P3m7FqwrQ49Riviv9cKVsmfXwblARlJeSVj/RyeBdmE3KTuH5iBwgQBlZWO4uMBedJxouguHdUJyN2vwOEx/aS5tvD6irrXiEbQeEiGSwPiZhIPUAjBIEbr4xVGfRt31AHwXIiAFBHxQUX9X1/hSpPtSSgawohtbqzVjyY4vJdYE77eIlEnbjm7AHiGI9TWkjvJyI3jbxQod4lVEFvL1Kh5JWjfPVOSGtg84A2yqU6VhTBFn3GZ3YVqDY3spi7LRhTorzso9McK467vfq0Xu8+BiROT6PGW1/e9vHwRowJ2wcbe0Oy3xc9gdd7bB7sxrjC4y4B7wvARsw6rxhAC9oEb3trPxzNZjhOmBN5VIk+gF5Nuz8UlPGxCl6KSj6Ot41Th486U9UjJ96Wlo4/CErFTSq7Gi20K1e0EmS0up0PNaguFjPvt22XrREdEhxCJmlfjQ7cCt4boUixRUphIk4J3zYhycL9iYgMjMVj4aqOQPSbjMUvhw9fi/GCEMZIn5aw0dguZVe7z+Yc/Dy7wRmwRRj68rYgcuDdn61k1gWN0Lwt9BQ8BqOg+lFSC0VDv+DRq8qHYfmvt1H0s4mhfnlWynPNMxFITGcsEWmE2IqZ0yAEcSEIJItUfE3S9vetuEOHm8iE60GGusAye9W7+sbPgJiKt1Dyg62CrzacymOS572mvijaC8wFJ7a4ilS7r06gNRYvKVyON7IdRrO4iHrdZ07KfNqLi9HGUBHcvAT5xA2voGGJoPNpwkEZnEXyQRGouZPDh3johRwJz4ep8vQknE9C5+d38kyAvZj1hFae+bRW2TLSwf0ifL5+YWJRbn6ZY5EMBsy7J+9KOK1la7chfjWeg6oE9ctXAUAKPM9lM87CK38T70BjvxImeJIS+qqsd+7hk7CH4fkKqKD3tKlxYGQfmjfalnQqdJ2g3XFZMcEIfsG34nzbvb9tRk4OfTsiser4kRTMT83J71h6n3bRO/p6IUt8bqdOdq89hcQWO4nFlrulAT5MlaI9sC0dJVaIpURqBeeF24aHzmTvRUzNX0/t8NkQ1RS+odO5X+kCefCOnGJVBa56U6tNWvOH2y+DTbGmbPg7imNzadxGAL4h3axxrwzi3zCmxcaYeDen8WwczeUGCbu+DUdd0CZ5MPWYvXoMovObxPB6hSucwnrkpXFiRL7NW8Di9XkR7rm/iaSPrmCe25pB5QOW2FZopyeUjhRL74M9lb6EW1A1bfVK0iz+4vmLphit2IcIqfFqq2EiYTA7WowhBVQESI9Rx5ulFuOiKBhUT+IVoh6Z2iKyVAjnI880zXWH4S4uGGIxmEoLC/SooKk1D0sPO9gbPU/d2nzfRT7qzWj3Fohd78LK1VZKXCRxuIROIq9UIWqXFUU5CN6PsJjDdoS1mA71ogKbA+az6llCd2s6oFuyCbx/Bgv5Ig+suXj56VMdU1GGOOcczak7ObjXWRZG0lOMu1K8SZSGixg9C3ykQkslRefNgh7wk0NHnykeSuOuLqLOu2nLjfcOVr1DxRfhZ8lcTDixyrx6O0FlgMdaEFZtGSi7rIYmJaVnJ1xNNf3EoBfilK2kvhGLs+bQncXq/tTWRMAQKfCjik2Ys6rjRiXk8YLdXSrvWUDoUVi0a/MKpo1jSAZRqx33HEWJY1S6upnDuEpLg86GzPm2qY0P/FBclpEM8DFb2uLamhZY6JP2rCasMnZkmKWZsGogzSohrxpqP1WAxW4KGJVMphCAe3M4ySBv4XWqQHSyjqYrxLfWJ/WNB9GcUJJ2BkXWJEZJp5b4MeLPO90zw4EIzWREMFqY7mkCws1CPSw9+Wp80ANYR8q7OG5lqbMClsHIGRDPXX29Hpe+U6KQyXwiaZ4ESigJifuakkw5niV3NcJMVUzJBLl6MdwP1EdoUMVYPXHTS2dS0QLfpW6C0Tj84+yaYoVgwmHa2Cm2rPb6oIjyZT0csUw7JLA7SD7jXqyDohXE0eDwSEzbCa+TyQpDIEpw8KWbVyzJOGBGRBeeV8MMC5Imtj27JdLrpVObs75zSoKeRAoWibgIr/wg4vc8cBtMG5whZYXeO5VKJsuev6heSpJltaBJsSrqKWoPffeEZEcQlzWVvWcc0xuzIVEkAzfMnZHIVyg4G4t5z5TcGUW7oTebUQdQjuVlju1IXFvzlmJNMhqpTB/a65bCO/Qg82nssZebD6N7dxInvUt6aPkqXryQ+D3aD4HCR9pKbizW88nSyNWqe3L74uqgx1ek4cWFtizfq/v6ZjnFK1qPkEp7OH66HpukyuybB7NzXU0A9/uYtBdxoHhwSFwBVLwEvZV7Qft7H0IsTduEB4wIv92vkmDj9nVscmhV33zaKPXE10TXkkubRQkqy1uzlRlUctBHvM9spaNm2BKBzJCu2PoSS+tCAerc7AN4BRUo7ZQ1p6BGkxp2Ag4PPV6mkVcQ4wB2dHF4a0/xTKOlR3eWmOYMXStyZLRj6NV641A9odBtPvVzXafMXXC1Rav4HklWya8OzNDpZgJygi4wION0iW5QGqn1xb6abvovRjKPGkUjrojSJXzhoWMOgJ2aF6N4R+hJGNX75hBdCJX1ihK6Cb6beMmoWwLStdU+th5G7Ja5TRIw+oG6IgaqPbqEQSOK6yiPpEiWx42bUXf18xl4D29HIetd4QPgpEO0FTvE5ALwQgxp9FpuMnsrerXs+noOr/7hXF5JnmbKJR0wARfuO34Hx0Fs8Y1WHmgMhIYeZjedVPXmaaevLUNxJN2aJ00+7ick3UoscmlykLiKhql+X09IsBGjLStHZdIirbWQor04qGCechPJkx56zaAdPFCY5F+tk3M1cJAvUIXNqY2HeFfnJmaOuFXWYlpAuKxjlQiUs98C1za7frsOUM4Vf2XAqCce1cT9jYyaOB9wd1ovx+8dGO7qEXD35AbAyFUBOk1i3y+PzNuj191OrOEAm+CbJePSqBmLNirYEme9BFtns6swwbwHq6d0XokRYV1QInLjnKkR+8lCz1F8josHQDL4evSjM1OhOtbL1RMA8pmip9wpe2dy7kNfY5Dfq9lLQLMZXofvo0cKp1Nh7Hqr7mgWGVkQL6B3r915gqta7ZWVF1GlydMpeXNUbUVPg3UGwnsRVRSNiH12cNcrNL1ukrADa+FQQC+3RcOYNc9pkqrQnD8vyhSw7I1R368cqvCCTEYvalBq0kvVMvJQpDxblKM5XtXzQWFmJp5HzWijuulrJs6b6d0tMbgFua0Mjd6GLqazYz6kQSY6aJkuVBFNSk0TJARjjyfEd+v9qJegVJYsCBOlWOeWD3U1NU9vkhZEqizsgGm17OwzdRFavgq/2sBSXL50eCS61T9Fo73nKBN4zFRWr4XSubfm3kNkZJCCPhZz1fPJPUBLYKv5dXfcNRfMrCOsihSbsyeJ22loQHvxF71AJNvDzfx0NT7Pki313Igfr5asz7Vp86oBxg5P48/gPS2KPZqw7BoLoBouknhSYml9yT15CU4UC37Hea4X1FurWX4BECORVgV1kyTbXV/V36rjUc/7PRhEqLUrUH2vE2E2M7sV7b2GooIS+tvDbpvA8BW5eTaTvRIn0pnRkAT8U783LuGdr1u10ztm1Wq8P+tEKKCiu8m9UsZQZcZJ6beiOhRSb4a0i/dXyNi68sOOc6Vd1tinx3YlYuXUS0/ueW80K2SOoWf6fhKdc6EqDuh6ktx0lAC548TzZi6aLIUKpzXedSzSeqlqlS12mZ4abnWnU57pQEpZ3djKEN1UZcTFDBSBJ1totgwiYNpguVj7HrCWH8jPZks6z3xZfl6FMH9o+fMwdYIJGh15cg2T+iJ2HeBLJrzFRGgM+QOXp854NEJgByb8GOBtmHW9DggtgLlhlsqYsCu9RihEcBVe4539DDZXS0NfIhieEwPKYsbeBrTcj982dwodPnqOmLneg+nwnEMqTvYToDNYbxnSfck5Hpv5JKkb917eemgEqinr360t82bDSGqmMC/FXDj3Ns/0WypZKY+5h8ZoAmzzm/jY4cj2WVIhS9Nb3GQCLdJ8MlTI6NnEPbm7hY1swpf9lXSlxBfFvCW3C6vSPFvCeySbfqSCJ7+IauRMAlgJIdzQ5K2RoPk5G+nmdm+Jj9uF55lP3aRDdKbDY8LDldKMc68q0ntvpp466E0Qyy1mjG7gDqoa/FuWm5CxvQL6nss06izvHiPtTqi4g+m3lNyeDNY3WyfCubf4AWjcEsPKiMx7scfWEBuTyChzlTX6TpjQXYof/HhgWnCG76hI79fxr6uu0vvYtigQxd72Mrx9txZGC2uq8MKDZewYuBVK4soKs999svKe8nI6ESylwzLdPHc1nw+SuV8dcsqnSec/rPjlxTV/u7His3321MNx+j0UGqShJYk3k6OsETf3Efl+K5bGVQaPYEat1wWIl9XN0BIrmH3QcpQxXt3MEJRq0yfAN5jA3hnsATzdmSmkkTBMt1WCl7rtdyvjU6tYltCF95DKrUQT7uiwvUWzq1msS1T56iBMevEqxfLqmEuqw0wGFZtVgFA9LreRMBjfLeHemGZ40/bIDHCsLaXl9VeU62fK7oJSJDW/brruCuW9yZoFuc7B9p0/2yXv4usUHC3TxcfMbd88jhJHLyvhxNHy+G5Z5sE7tN9xKAu48LNn0uaxX6dsJnNDBkqQd8Wsk7A+KFscp+us+85YvXg6rJods8bXmJNjzpW6FhuBxh3INd4vJpRZC8IZfDOwMEp/2tqLK4PqFN6FlKhK9joX7Cr/Lz9f21IEwXnbEtPpHKNuYolEY1AkV1o0uqcM1BH8jPbr/JzkR4nT4wS+jXJ7zxTMva8OHaANkT9vx9uukaUurftt50dnpxZEbGHABD12p3XDT05w56gK4ii0LYjBIIkdfhx2CXAeCewEiPMIouhN8wDE06F5JKJErM52Tgd3bW6wrlnasY9IvELw7o1iZ7bCyWxS2Lq2tHNa7xsI3EdhjGQO9AO8iGwYWKQRpP3Bez9mdUW73R4Q06/GuLdpMuziQpGHMrVbb+ykBhyvLdLnco8Uwg7yDgSnDCUXQ4zREudBu4WoaAZUXu3XveQlckVpGgD6p+u81R6iqOrNvWnrXS97awxXgQZZo9xvIE1pENhfTSzq4wJN0ahHtOBJEqm8luk9qYZC8RvwcZIjvQOg9pDQIwh4FDzcOhgyu8JuHZrcwHn1DJkC1te152o/RJq8ysCtO9f3G8TVpoD99nKaAwjxhKNRjaQPEG979CQoqSs4pQKvFm0FSRtTwBC04CPBrhrnWMYxog4WgeacM97mLotP269sjrQ37OIGNvlyjwwa/UyfgIAr9qd/J6Ka1nC9W4gtoFSWCkyUcT9BbN0nDAcBfmRHzMOysPILJIyzJeBpCKRWlCJfbyOJUBU0DVOtDAiiaGil/QhUfI4WJevt2SaIryT4LEhKo6/SY63gxR+OsYBIOTd5GxmUhkbiieLkib5xBB/e2Lt032/hBblP0EehtkyDXDdEKsmxqiCEGR1F+oIxTRIq4N2B5eJ92qBR+31uNTh3yxsctwOk8rehLdBBaVTbUgCQoeZKrxMltoKNtbmULGyw1ZQK7IgI4poj3t5geTrkAwQ7l2sW15CJHpy0LFBpFCAtCikfEdZa5pUrxowAIJCXKYjobVnDFHhLX6DQlNOCGKDliki73ABVnt+ciBN0uIRA4y25LhkQCbLkHGd6VoPOMIKAET3ccAEB09tHYrU8QAMYwEcXj9LLAqBWkrs8GRCPxYjXN8DJUvtGW+NESBM94ngNUl7cezDAHyeo7l5GgT5Yd9x7fwDGPaVGBL1Q6ID9rTcrjp6vY6dz9XsQlNDGO37XYBQRnf/CZxiHhtxYo/ddxTEEdGcTrK/uvGtphTfkuSJO0rtMEzVjlquFAsAbfVbS63ZnXwzD/OlPf//NN4Kk8j/avsF/uhPwQ39cQ98k6fuj7sLkx6lbxjj97vs/fvPNp3sQ83j89PbpScI5vIS+XEf4ISKwJI27JP3um19fnfjpwsHPY9//Ij+m8zK2ny8w/PBJ9GLldJq+Fv+0x29l0z1O+/mD//yr6NqPcPpIx7Ebf6VbPxbt/PVS3/6zbjz+/GGExyfTfpL49h++mvN58F/R9dG16U/+GZf2xy9XVL774qXfd9LffRiXVem4ph9znn50Y5EVbVh/XOY2YZv8oS7a9CMcs6VJ23n64We56Zh+uIbXf4b+fPm4m37owzn/IYymT7+/+/HHd1GnP/74Kw0/uf6a+cmN16evTf+i4A8/xefbZX7/gfrDVGTffv+1+d/+4+WiPxhjN6fxnCZ/MD7b90+/cdK36Z7G3/6el9qwSS8F40+K/LevZX788dPHH3/89o+f3puwaK/3f/jtnC9WXXP+psF/JXJtV4XZF6lP4fmrCXEY52nyO9//+y+Kf7Loa5d98tTXS/1s3N8Y/lfSBvoqca1jmtOG34v59zL3VwnTdmNzpcqnVEiv2d99/xGlebgW3fhLnhTvLyv88Dn+xfTZxj9+peHXSvwkVExFO81he6H7F/l/+LhQ8/3vSv8y6bcg++XL97+1G/4PAeznJPwcouWz9P8XcuFfwfaqWPm/AVr+826fMDt2S5Z/xu70OW6f6l3+seVXOn70XyJVtNmvRD9NjZdxvPD8kbZrMXbtJ2x/XGj/N1F/rbfU84WeX+5v/XBp/LVf/vmb395P+/aTTr9xyOfxP8S/M/p/Ww0+r/C5IJi6zbM2z/3OYv/l50IF//HPX339828C1K5/ulD9k0eufOmP736zYbwln6Zk6Xy9fff9vxLNL3764ctfvyTlvy/Rbp8C+x+UZp8K3M+0+cXhV1S/4tQv3y4o/vT5r7D7NYiuib+i6j99fHtx9bd/NfmvWelvSV8J87vSvwbHF9nfeOwnb73aaek/3SxMk49PtfljPvr0hy+08JPgr3xy7f8XBvi8/c8U8Lv4+7nifeX7Lz79G92Akh5RF46J1M5XjJZ+/jdC/l/bL2ZYc9f3lwnR8bFcWP7hd3ntZ31gFPoPaUJebbr3nzn2/zHNftHk+2/+D5ygyaYwKwAA'

FILE_TYPE = '.py'


def load_source():

    try:

        data = base64.b64decode(
            PAYLOAD
        )

        return gzip.decompress(
            data
        )

    except Exception as error:

        print(
            "[OPN] Payload error:",
            error
        )

        return None


def run_python(source):

    try:

        # Preserve the original command-line arguments.
        sys.argv[0] = os.path.abspath(__file__)

        code = compile(
            source.decode("utf-8-sig"),
            "<OPN-Protected-Python>",
            "exec"
        )

        namespace = {
            "__name__": "__main__",
            "__file__": os.path.abspath(__file__),
            "__package__": None,
            "__cached__": None,
        }

        exec(
            code,
            namespace,
            namespace
        )

        return 0

    except SystemExit as error:

        # Preserve normal sys.exit() behavior.
        if error.code is None:
            return 0

        if isinstance(error.code, int):
            return error.code

        print(error.code)
        return 1

    except Exception as error:

        print(
            "[OPN] Python execution error:",
            error
        )

        return 1


def run_bash(source):

    try:

        # Execute through the system bash while preserving
        # the current environment and command-line arguments.
        result = subprocess.run(
            [
                "bash",
                "-c",
                source.decode("utf-8-sig"),
                "OPN-PROTECTED",
                *sys.argv[1:]
            ],
            env=os.environ.copy(),
            cwd=os.getcwd()
        )

        return result.returncode

    except Exception as error:

        print(
            "[OPN] Bash execution error:",
            error
        )

        return 1


def main():

    source = load_source()

    if source is None:
        return 1

    if FILE_TYPE == ".py":
        return run_python(source)

    if FILE_TYPE == ".sh":
        return run_bash(source)

    print(
        "[OPN] Unsupported file type."
    )

    return 1


if __name__ == "__main__":

    try:

        sys.exit(
            main()
        )

    except KeyboardInterrupt:

        print(
            "\n[OPN] Stopped by user."
        )

        sys.exit(130)

    except Exception as error:

        print(
            "[OPN] Unexpected error:",
            error
        )

        sys.exit(1)
